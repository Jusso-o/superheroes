SELECT * FROM superhero superhero_name

